 <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#">Công ty gia dụng Thiện Mỹ</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a style="padding-right:50px" href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> <?php echo $_SESSION['phone'];?><i class="caret" style="width:80px" onclick="openPopUp('customer.php','Đăng ký số điện thoại',450,400)"><?php if($_SESSION['phone']) echo "Số khác"; else echo "Số di động";?></i>
                                </a>
                                <!-- <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="login.html">Logout</a>
                                    </li>
                                </ul> -->
                            </li>
                        </ul>
                 		<?php 
                        $file = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);;
                        ?>
                        <ul class="nav">
                            <li <?php if($file=="product_sale_list.php") echo "class='active'";?> >
                                <a href="product_sale_list.php">Bảng giá sỉ</a>
                            </li>
                            <li <?php if($file=="product_order_list.php") echo "class='active'";?>>
                                <a href="product_order_list.php">Xem lại đơn hàng vừa đặt</a>
                            </li>
                            <li <?php if($file=="product_order_list_checked.php") echo "class='active'";?>>
                                <a href="product_order_list_checked.php">Xem lại đơn hàng đã hoàn tất</a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>