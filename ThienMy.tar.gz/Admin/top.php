 <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#">Trang quản lý</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> Thiên Mỹ <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="login.html">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <?php 
                        $file = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);;
                        ?>
                        <ul class="nav">
                            <li <?php if($file=="product_sale_list.php") echo "style='background-color:#a9dba9;border-color:#46a546;font-weight: bold;'";?>>
                                <a href="product_sale_list.php?a=1">Bảng giá sỉ</a>
                            </li>
                            <li class="dropdown" <?php if($file=="order_list_new.php" || $file=="order_list_checked.php") echo "style='background-color:#a9dba9;border-color:#46a546;font-weight: bold;'";?>>
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Đơn đặt hàng <i class="caret"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="order_list_new.php">1. Đơn đặt hàng chưa xác nhận</a>
                                    </li>
                                    <li>
                                        <a tabindex="0" href="order_list_checked.php">2. Đơn đặt hàng đã xác nhận</a>
                                    </li>                                    
                                </ul>
                            </li>
                            <li class="dropdown" <?php if($file=="customer_list.php" || $file=="customer_vip_list.php" || $file=="customer_contact_list.php") echo "style='background-color:#a9dba9;border-color:#46a546;font-weight: bold;'";?>>
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Khách hàng <i class="caret"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="customer_list.php">1. Danh sách khách hàng</a>
                                    </li>
                                    <li>
                                        <a tabindex="0" href="customer_vip_list.php">2. Khách hàng VIP</a>
                                    </li>
                                    <li>
                                        <a tabindex="0" href="customer_contact_list.php">3. Khách hàng cần hỏi thăm</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="dropdown" <?php if($file=="product_type_list.php" || $file=="product_list.php") echo "style='background-color:#a9dba9;border-color:#46a546;font-weight: bold;'";?>>
                                <a href="#" data-toggle="dropdown" class="dropdown-toggle">Sản phẩm <b class="caret"></b>

                                </a>
                                <ul class="dropdown-menu" id="menu1">
                                    <li>
                                        <a href="product_type_list.php">1. Loại sản phẩm 

                                        </a>                                       
                                    </li>
                                    <li>
                                        <a href="product_list.php">2. Sản phẩm</a>
                                    </li>
                                    <li>
                                        <a href="price_rate_list.php">3. Tỉ lệ lợi nhuận</a>
                                    </li>
                                    <!-- 
                                    <li class="divider"></li>
                                    <li>
                                        <a href="#">Other Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Other Link</a>
                                    </li> -->
                                </ul>
                            </li>
                            <li class="dropdown" <?php if($file=="product_in_list.php" || $file=="product_out_list.php" || $file=="expense_list.php") echo "style='background-color:#a9dba9;border-color:#46a546;font-weight: bold;'";?>>
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Nhập xuất <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="product_in_list.php">1. Nhập hàng</a>
                                    </li>
                                    <li>
                                        <a tabindex="0" href="product_out_list.php">2. Xuất hàng</a>
                                    </li>
                                    <li>
                                        <a tabindex="0" href="expense_list.php">3. Chi phí khác</a>
                                    </li>
                                </ul>
                                
                            </li>
                            <li class="dropdown" <?php if($file=="bill_list.php" || $file=="store_list.php") echo "style='background-color:#a9dba9;border-color:#46a546;font-weight: bold;'";?>>
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Thống kê <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="bill_list.php">1. Đơn hàng</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="store_list.php">2. Tồn Kho</a>
                                    </li>
                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>