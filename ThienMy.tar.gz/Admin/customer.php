<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
 <?php 
 if($_GET["id"]){
 	$sql="select * from customer where id_customer_phone=".$_GET["id"];
	//echo $sql;
	$rse=mysql_db_query($db,$sql,$con);	
	$rowe=mysql_fetch_array($rse);
 	$phone=$rowe["phone"];
 }

 if ($_POST["sm_2"]){ 	
	$phone=$_POST["phone"];
	$created_datetime=date('Y-m-d H:m:s',time());
	$sMesage='';
	 if($_POST["phone"]=='')   
	 	$sMesage="Bạn chưa nhập Số điện thoại";	
	 
	try{
		if($sMesage==''){
			if($_GET["id"]){
					$sql="update customer set phone='$phone',updated_datetime='$created_datetime',created_datetime='$created_datetime' where id_customer_phone=".$_GET["id"];					
			}else{
					$sql="insert customer(phone,updated_datetime,created_datetime) values ";
					$sql=$sql."('$phone','$created_datetime','$created_datetime')";
			}
			
			$sql2="select phone,id_customer from customer where phone=".$phone;
			$rs2=mysql_db_query($db,$sql2,$con);
			while($row2=mysql_fetch_array($rs2)){
				$phone_registed=$row2['phone'];
				$_SESSION['phone']=$phone_registed;
				$_SESSION['id_customer']=$row2['id_customer'];
				
				if ($_GET['redirect']){
					header('Location: '.$_GET['redirect']);
					exit;
				 }
			
			} 	
			
			if(!$phone_registed){
				//echo $sql;
				if (mysql_db_query($db,$sql,$con)){
					 $sMesage="Thao tác thành công";
					 $_SESSION['phone']=$phone;
					 $_SESSION['id_customer']=mysql_insert_id($con);
					if ($_GET['redirect']){
					 	header('Location: '.$_GET['redirect']);
						exit;
					 }				 
					 	?>
					 	<script>refreshAndClose();</script>
					 	<?php				 	 
				 }else{
					 $sMesage="Thao tác không thành công"; 		 
			     }
			}else{
				?>
			 	<script>refreshAndClose();</script>
			 	<?php
			}
		     
		}
	}catch (Exception $e){
		//writeLog($e);
	}
     
 }
 ?>
    <body>
        <?php //include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php //include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid" >
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Thông tin liên hệ</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <form class="form-horizontal" id="frm_1"  method="post" enctype="multipart/form-data">
                                      <fieldset>
                                        <div class="control-group error" style="text-align: center">
                                          <label class="control-label" for="inputError" style="padding-left:22%;width:50%;text-align:left"><?php echo $sMesage; ?></label>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="phone">Vui lòng nhập số điện thoại di động của bạn<span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="phone" value="<?php echo $phone;?>">                                            
                                          </div>
                                        </div>
                                                                              
                                       <div class="form-actions">
                                          <button type="submit" name="sm_2" value="1" class="btn btn-primary">Xác nhận</button>
                                          <button type="reset" name="cc_1" value="1" class="btn">Nhập lại</button>
                                       </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div>
 
        <!--/.fluid-container-->
        
    </body>

</html>