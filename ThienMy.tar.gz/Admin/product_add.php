<!DOCTYPE html>
<html>
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
 <?php 
 if($_GET["id"]){
 	$sql="select * from product where id_product=".$_GET["id"];
	//echo $sql;
	$rse=mysql_db_query($db,$sql,$con);	
	$rowe=mysql_fetch_array($rse);
 	$product_code=$rowe["product_code"];
 	$id_product_type=$rowe["id_product_type"];
	$product_name=$rowe["product_name"];
	$product_note=$rowe["product_note"];
	$size=$rowe["size"];
	$price_buy=$rowe["price_buy"];
	$adjust_value=$rowe["adjust_value"];
 }

 if ($_POST["sm_1"] || $_POST["sm_2"]){ 	
	$arr_product_type=explode("_",$_POST["id_product_type"]);
	$id_product_type=$arr_product_type[0];
	$product_type_code=$arr_product_type[1];
	$product_code=$product_type_code."-".substr(time(),-4);
	$product_name=$_POST["product_name"];
	$product_note=$_POST["product_note"];
	$image_name=$_POST["image_name"];
	$size=str_replace(',','.',$_POST["size"]);
	$vowels = array(",", ".");
	$price_buy=str_replace($vowels,'',$_POST["price_buy"]);	
	$created_datetime=date('Y-m-d H:m:s',time());
	$sMesage='';
	 if($_POST["id_product_type"]=='')   
	 	$sMesage="Bạn chưa nhập Mã loại sản phẩm";	
	 //if($_POST["product_code"]=='')   
	 	//$sMesage.="<br>Bạn chưa nhập Mã sản phẩm";		
	 if($_POST["product_name"]=='')   
	 	$sMesage.="<br>Bạn chưa nhập Tên sản phẩm";
	 if($_POST["price_buy"]=='')   
	 	$sMesage.="<br>Bạn chưa nhập Giá mua";			
	
	try{
		if($sMesage==''){
			//Calc price_sale
			$sql_rate="select * from price_rate order by from_value asc";
	        $rs_rate=mysql_db_query($db,$sql_rate,$con);		
	        while($row_rate=mysql_fetch_array($rs_rate)){
	        	$arr_rate[]=$row_rate;
	        }
	        foreach($arr_rate as $key => $value) {
				if(($value['from_value']<=$price_buy)&&($price_buy<=$value['to_value']))
					$revenue_percent_default=$value['percent'];
				}
         	$price_sale=$price_buy+round((($price_buy*$revenue_percent_default)/100),2);
         	$price_sale_adjust=$price_sale;
			if($adjust_value){
               $operation=substr($adjust_value,0,1);
               $adjust_value_2=substr($adjust_value,1);
               if($operation=="-")
               		$price_sale_adjust=$price_sale-$adjust_value_2;
               else
               		if($operation=='+')
                    	$price_sale_adjust=$price_sale+$adjust_value_2;
                    else
                    	$price_sale_adjust=$price_sale+$adjust_value;	
              //$revenue_percent_adjust=round(((($price_sale_adjust-$row['price_buy'])*100)/$row['price_buy']),2);
            }
	        //End calc price_sale
			$image_name="";
			if (is_uploaded_file($_FILES['image_name']['tmp_name'])) {
				$uploads_dir='product_image';
				$image_name=$_FILES['image_name']['name'];				
        		move_uploaded_file($_FILES['image_name']['tmp_name'], "$uploads_dir/$image_name");        		
			}
			if($_GET["id"]){
				if($image_name)
					$sql="update product set product_name='$product_name',product_note='$product_note',image_name='$image_name',price_buy='$price_buy',price_sale='$price_sale_adjust',updated_datetime='$created_datetime' where id_product=".$_GET["id"];
				else
					$sql="update product set product_name='$product_name',product_note='$product_note',price_buy='$price_buy',price_sale='$price_sale_adjust',updated_datetime='$created_datetime' where id_product=".$_GET["id"];					
			}else{
				if($image_name){
					$sql="insert into product(id_product_type,product_code,product_name,product_note,image_name,size,price_buy,price_sale,updated_datetime,created_datetime) values ";
					$sql=$sql."('$id_product_type','$product_code','$product_name','$product_note','$image_name','$size','$price_buy','$price_sale_adjust','$created_datetime','$created_datetime')";
				}else{
					$sql="insert into product(id_product_type,product_code,product_name,product_note,size,price_buy,price_sale,updated_datetime,created_datetime) values ";
					$sql=$sql."('$id_product_type','$product_code','$product_name','$product_note','$size','$price_buy','$price_sale_adjust','$created_datetime','$created_datetime')";
				}
			}
			//echo $sql;
			if (mysql_db_query($db,$sql,$con)){
				 $sMesage="Thao tác thành công";
				 if($_POST["sm_1"]){
				 	?>
				 	<script>refresh();</script>
				 	<?php
				 }else{
				 	?>
				 	<script>refreshAndClose();</script>
				 	<?php
				 }	 
			 }else{
				 $sMesage="Thao tác không thành công"; 		 
		     }
		     if (substr(mysql_error(),0,9)=='Duplicate'){
		     	 $sMesage="Mã sản phẩm này đã tồn tại. Vui lòng nhập mã khác.";
		     }
		}
	}catch (Exception $e){
		//writeLog($e);
	}
     
 }
 ?>
    <body>
        <?php //include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php //include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid" >
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Nhập sản phẩm</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <form class="form-horizontal" id="frm_1"  method="post" enctype="multipart/form-data">
                                      <fieldset>
                                        <div class="control-group error" style="text-align: center">
                                          <label class="control-label" for="inputError" style="padding-left:22%;width:50%;text-align:left"><?php echo $sMesage; ?></label>
                                        </div>
                                        <?php 
									 	$sql="select * from product_type order by product_type_name";
										//echo $sql;
										try{
											$rs=mysql_db_query($db,$sql,$con);					  
															
										}catch (Exception $e){
											//writeLog($e);
										}
									    ?>
                                        <div class="control-group">
			  								<label class="control-label">Loại sản phẩm<span class="required">*</span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_product_type" <?php if ($id_product_type) echo "readonly"; ?>>
			  										<option <?php if ($id_product_type) echo "disabled"; ?> value="">Chọn loại...</option>
			  										<?php while($row=mysql_fetch_array($rs)){ 
			  											if($id_product_type==$row['id_product_type']){
			  										?>
			  										<option value="<?php echo $row['id_product_type']."_".$row['product_type_code'];?>" selected><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
			  										<?php 
			  											}else{
			  											?>
			  										<option <?php if ($id_product_type) echo "disabled"; ?>  value="<?php echo $row['id_product_type']."_".$row['product_type_code'];?>"><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
                                        <!-- <div class="control-group">
                                          <label class="control-label" for="product_code">Mã sản phẩm <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="product_code" value="<?php echo $product_code;?>">                                            
                                          </div>
                                        </div> -->
                                        <div class="control-group">
                                          <label class="control-label" for="product_name">Tên sản phầm <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="product_name" value="<?php echo $product_name;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="size">Kích cỡ <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="size" value="<?php echo $size;?>" <?php if ($id_product_type) echo "readonly"; ?>>                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="price_buy">Giá mua(bảng giá) <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="price_buy" value="<?php echo $price_buy;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="image_name">Hình sản phầm </label>
                                          <div class="controls">
                                            <input type="file" class="span6" name="image_name" value="<?php echo $image_name;?>">                                            
                                          </div>
                                        </div>                                         
                                        <div class="control-group">
                                          <label class="control-label" for="product_note">Chú thích</label>
                                          <div class="controls">
                                            <textarea name='product_note' rows="3" class="input-xlarge textarea" placeholder="Enter text ..." style="width: 90%;"><?php echo $product_note;?></textarea>
                                          </div>
                                        </div>                                      
                                       <div class="form-actions">
                                          <button type="submit" name="sm_1" value="1" class="btn btn-primary">Save</button>
                                          <button type="submit" name="sm_2" value="1" class="btn btn-primary">Save and Close</button>
                                          <button type="reset" name="cc_1" value="1" class="btn">Reset</button>
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div>
 
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
	
	<script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>