 <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <div style="text-align:left; float:left;">
	                    <br>Công ty TNHH Gia dụng Thiện Mỹ 
	                    <br>Email:
	                    <br>Liên hệ: 
	                    <br> Mỹ Đạt: 097 701 4848
	                    <br> Hạnh B: 090 848 1006                                 
                    </div>
                    <?php 
                    $sql="select * from customer where id_customer=".$SESSION['id_customer'];
                    //echo $sql;
                    $rs=mysql_db_query($db,$sql,$con);					  
					while($row=mysql_fetch_array($rs)){
					?>
                    <div style="text-align:right; padding-right:100px;">
	                    <br>Thông tin khách hàng 
	                    <br>Đại lý: <?php echo $row['agent_name'];?>
	                    <br>Địa chỉ: <?php echo $row['address'];?> 
	                    <br>Liên hệ: <?php echo $row['fullname'];?>
	                    <br>Điện thoại: <?php echo $row['phone'];?>                                
                    </div>
                    <?php }?>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>