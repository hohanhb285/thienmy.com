<!DOCTYPE html>
<html>
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
 <?php 
 if($_GET["id"]){
 	$sql="select * from product_in where id_product_in=".$_GET["id"];
	//echo $sql;
	$rse=mysql_db_query($db,$sql,$con);	
	$rowe=mysql_fetch_array($rse);
 	$product_code=$rowe["product_code"];
 	$id_product=$rowe["id_product"];
	$size=$rowe["size"];
	$quantity=$rowe["quantity"];
	$price_in=$rowe["price_in"];
	$product_in_note=$rowe["product_in_note"];
}

 $id_product_type=$_POST["id_product_type"];
 if(!$_GET["id"]){
 	$arr_product=explode("_",$_POST["id_product"]);
	$id_product=$arr_product[0];
	$product_code=$arr_product[1];
	$size=$arr_product[2];
 }
 if ($_POST["sm_1"] || $_POST["sm_2"]){ 	
	$arr_product=explode("_",$_POST["id_product"]);
	$id_product=$arr_product[0];
	$product_code=$arr_product[1];
	$size=$arr_product[2];
	$quantity=intval($_POST["quantity"]);
	$vowels = array(",", ".");
	$price_in=str_replace($vowels,'',$_POST["price_in"]);	
	$product_in_note=$_POST["product_in_note"];
	$created_datetime=date('Y-m-d H:m:s',time());
	$sMesage='';
	 if($_POST["id_product"]=='')   
	 	$sMesage="Bạn chưa chọn Sản phẩm";	
	 //if($_POST["product_code"]=='')   
	 	//$sMesage.="<br>Bạn chưa nhập Mã sản phẩm";		
	 if($_POST["quantity"]==''||$_POST["quantity"]==0)   
	 	$sMesage.="<br>Bạn chưa nhập Số lượng nhập hàng";
	 if($_POST["price_in"]=='')   
	 	$sMesage.="<br>Bạn chưa nhập Giá nhập hàng";			
	
	try{
		if($sMesage==''){
			if($_GET["id"]){
					$sql="update product_in set quantity='$quantity',price_in='$price_in',product_in_note='$product_in_note',updated_datetime='$created_datetime' where id_product_in=".$_GET["id"];					
			}else{
					$sql="insert into product_in(id_product,product_code,size,quantity,price_in,product_in_note,updated_datetime,created_datetime) values ";
					$sql=$sql."('$id_product','$product_code','$size','$quantity','$price_in','$product_in_note','$created_datetime','$created_datetime')";
				
			}
			//echo $sql;
			if (mysql_db_query($db,$sql,$con)){
				 $sMesage="Thao tác thành công";
				 if($_POST["sm_1"]){
				 	?>
				 	<script>refresh();</script>
				 	<?php
				 }else{
				 	?>
				 	<script>refreshAndClose();</script>
				 	<?php
				 }	 
			 }else{
				 $sMesage="Thao tác không thành công"; 		 
		     }
		     
		}
	}catch (Exception $e){
		//writeLog($e);
	}
     
 }
 ?>
    <body>
        <?php //include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php //include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid" >
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Nhập hàng</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <form class="form-horizontal" id="frm_1"  method="post" enctype="multipart/form-data">
                                      <fieldset>
                                        <div class="control-group error" style="text-align: center">
                                          <label class="control-label" for="inputError" style="padding-left:22%;width:50%;text-align:left"><?php echo $sMesage; ?></label>
                                        </div>
                                        <?php 
									 	$sql="select * from product_type order by id_product_type desc";
										//echo $sql;
										try{
											$rs=mysql_db_query($db,$sql,$con);					  
															
										}catch (Exception $e){
											//writeLog($e);
										}
									    ?>
                                        <div class="control-group">
			  								<label class="control-label">Loại sản phẩm<span class="required"></span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_product_type" onchange="this.form.submit()">
			  										<option value="">Chọn loại...</option>
			  										<?php while($row=mysql_fetch_array($rs)){ 
			  											if($id_product_type==$row['id_product_type']){
			  										?>
			  										<option value="<?php echo $row['id_product_type'];?>" selected><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
			  										<?php 
			  											}else{
			  											?>
			  										<option value="<?php echo $row['id_product_type'];?>"><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
			  							<?php 
			  							if($_POST['id_product_type'])
			  								$sql="select * from product where id_product_type=".$_POST['id_product_type']." order by id_product_type desc";
			  							else
									 		$sql="select * from product order by id_product_type desc";
										//echo $sql;
										try{
											$rs=mysql_db_query($db,$sql,$con);					  
															
										}catch (Exception $e){
											//writeLog($e);
										}
									    ?>
                                        <div class="control-group">
			  								<label class="control-label">Sản phẩm<span class="required">*</span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_product" <?php if ($_GET["id"] && $id_product) echo "readonly"; ?> onchange="this.form.submit()">
			  										<option <?php if ($_GET["id"] && $id_product) echo "disabled"; ?> value="">Chọn sản phẩm...</option>
			  										<?php while($row=mysql_fetch_array($rs)){ 
			  											if($id_product==$row['id_product']){
			  										?>
			  										<option value="<?php echo $row['id_product']."_".$row['product_code']."_".$row['size'];?>" selected><?php echo  $row['product_code']."-".$row['product_name']."-".$row['size'];?></option>
			  										<?php 
			  											$price_buy=$row['price_buy'];
			  											}else{
			  											?>
			  										<option <?php if ($_GET["id"] && $id_product) echo "disabled"; ?>  value="<?php echo $row['id_product']."_".$row['product_code']."_".$row['size'];?>"><?php echo  $row['product_code']."-".$row['product_name']."-".$row['size'];?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
                                        <div class="control-group">
                                          <label class="control-label" for="quantity">Số lượng nhập <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="quantity" value="<?php echo $quantity;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="price_buy">Giá mua(theo bảng giá)</label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="price_buy" readonly value="<?php echo $price_buy;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="price_in">Giá nhập(thực tế nhập) <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="price_in" value="<?php echo $price_in;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="product_in_note">Chú thích</label>
                                          <div class="controls">
                                            <textarea name='product_in_note' rows="3" class="input-xlarge textarea" placeholder="Enter text ..." style="width: 90%;"><?php echo $product_in_note;?></textarea>
                                          </div>
                                        </div>                                      
                                       <div class="form-actions">
                                          <button type="submit" name="sm_1" value="1" class="btn btn-primary">Save</button>
                                          <button type="submit" name="sm_2" value="1" class="btn btn-primary">Save and Close</button>
                                          <button type="reset" name="cc_1" value="1" class="btn">Reset</button>
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div>
 
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
        <script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>