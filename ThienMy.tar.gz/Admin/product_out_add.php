<!DOCTYPE html>
<html>
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
 <?php 
 if($_GET["id"]){
 	$sql="select * from product_out where id_product_out=".$_GET["id"];
	//echo $sql;
	$rse=mysql_db_query($db,$sql,$con);	
	$rowe=mysql_fetch_array($rse);
 	$id_product_in=$rowe["id_product_in"];
 	$id_customer=$rowe["id_customer"]; 	
	$product_code=$rowe["product_code"];
 	$id_product=$rowe["id_product"];
	$size=$rowe["size"];
	$quantity=$rowe["quantity"];
	$price_out=$rowe["price_out"];
	$product_out_note=$rowe["product_out_note"];
}

 $id_product_type=$_POST["id_product_type"];
 if($_POST["id_product_in"]){
	 $arr_product=explode("_",$_POST["id_product_in"]);
	 $id_product=$arr_product[0];
	 $id_product_in=$arr_product[1];
	 $product_code=$arr_product[2];
	 $size=$arr_product[3];
 }
 //echo "id_product_in:".$id_product_in;
 if(!$_GET["id"])
 	$id_customer=$_POST["id_customer"];
 if ($_POST["sm_1"] || $_POST["sm_2"]){ 	
	$quantity=intval($_POST["quantity"]);
	$vowels = array(",", ".");
	$price_in=str_replace($vowels,'',$_POST["price_in"]);	
	$price_out=str_replace($vowels,'',$_POST["price_out"]);	
	$product_out_note=$_POST["product_out_note"];
	$created_datetime=date('Y-m-d H:m:s',time());
	$sMesage='';
	 if($_POST["id_customer"]=='')   
	 	$sMesage="Bạn chưa chọn khách hàng";
	 if($_POST["id_product_in"]=='')   
	 	$sMesage.="<br>Bạn chưa chọn Sản phẩm cần xuất";	
	 //if($_POST["product_code"]=='')   
	 	//$sMesage.="<br>Bạn chưa nhập Mã sản phẩm";	
	 if($_POST["quantity"]==''||$_POST["quantity"]==0)   
	 	$sMesage.="<br>Bạn chưa nhập Số lượng nhập hàng";
	 if($_POST["price_in"]=='')   
	 	$sMesage.="<br>Giá nhập không có, kiểm tra lại giá nhập.";	
	 if($_POST["price_out"]=='')   
	 	$sMesage.="<br>Bạn chưa nhập Giá xuất hàng";			
	 	
	try{
		if($sMesage==''){
			if($_GET["id"]){
					$sql="update product_out set quantity='$quantity',price_in='$price_in',price_out='$price_out',id_customer='$id_customer',product_out_note='$product_out_note',updated_datetime='$created_datetime' where id_product_out=".$_GET["id"];					
			}else{
					$sql="insert into product_out(id_product_in,id_product,product_code,size,quantity,price_in,price_out,id_customer,product_out_note,updated_datetime,created_datetime) values ";
					$sql=$sql."('$id_product_in','$id_product','$product_code','$size','$quantity','$price_in','$price_out','$id_customer','$product_out_note','$created_datetime','$created_datetime')";
				
			}
			//echo $sql;
			if (mysql_db_query($db,$sql,$con)){
				 $sMesage="Thao tác thành công";
				 if($_POST["sm_1"]){
				 	?>
				 	<script>refresh();</script>
				 	<?php
				 }else{
				 	?>
				 	<script>refreshAndClose();</script>
				 	<?php
				 }	 
			 }else{
				 $sMesage="Thao tác không thành công"; 		 
		     }
		     
		}
	}catch (Exception $e){
		//writeLog($e);
	}
     
 }
 ?>
    <body>
        <?php //include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php //include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid" >
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Xuất hàng</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <form class="form-horizontal" id="frm_1"  method="post" enctype="multipart/form-data">
                                      <fieldset>
                                        <div class="control-group error" style="text-align: center">
                                          <label class="control-label" for="inputError" style="padding-left:22%;width:50%;text-align:left"><?php echo $sMesage; ?></label>
                                        </div>
                                        <div class="control-group">
			  								<label class="control-label">Khách hàng<span class="required">*</span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_customer">
			  											<option value="">Chọn khách hàng...</option>
			  										<?php 
												 	$sql="select * from customer where fullname<>'' or fullname is not NULL order by id_customer desc";
													//echo $sql;
													try{
														$rs=mysql_db_query($db,$sql,$con);					  
																		
													}catch (Exception $e){
														//writeLog($e);
													}
												    while($row=mysql_fetch_array($rs)){ 
			  											if($id_customer==$row['id_customer']){
			  										?>
			  										<option value="<?php echo $row['id_customer'];?>" selected><?php echo  $row['id_customer']."-".$row['agent_name']." - ".$row['fullname']." - ".$row['phone'];?></option>
			  										<?php 
			  											}else{
			  											?>
			  										<option value="<?php echo $row['id_customer'];?>"><?php echo  $row['id_customer']."-".$row['agent_name']." - ".$row['fullname']." - ".$row['phone'];?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
                                        <div class="control-group">
			  								<label class="control-label">Loại sản phẩm<span class="required"></span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_product_type" onchange="this.form.submit()">
			  											<option value="">Chọn loại...</option>
			  										<?php 
												 	$sql="select * from product_type order by id_product_type desc";
													//echo $sql;
													try{
														$rs=mysql_db_query($db,$sql,$con);					  
																		
													}catch (Exception $e){
														//writeLog($e);
													}
												    while($row=mysql_fetch_array($rs)){ 
			  											if($id_product_type==$row['id_product_type']){
			  										?>
			  										<option value="<?php echo $row['id_product_type'];?>" selected><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
			  										<?php 
			  											}else{
			  											?>
			  										<option value="<?php echo $row['id_product_type'];?>"><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
			  							
                                        <div class="control-group">
			  								<label class="control-label">Sản phẩm<span class="required">*</span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_product_in" onchange="this.form.submit()" <?php if ($id_product_in && $_GET["id"]) echo "readonly"; ?>>
			  										<option <?php if ($id_product_in && $_GET["id"]) echo "disabled"; ?> value="">Chọn sản phẩm...</option>
			  										<?php 
						  							if($_POST['id_product_type'])
						  								$sql="SELECT i.*,p.id_product_type,p.product_name,p.price_buy,p.price_sale,o.total_o FROM `product_in` i JOIN product p ON i.id_product=p.id_product and id_product_type=".$id_product_type." LEFT JOIN (select sum(ou.quantity) as total_o,ou.id_product_in FROM `product_out` ou GROUP BY ou.id_product_in ) as o ON i.id_product_in=o.id_product_in WHERE i.quantity>o.total_o or o.total_o IS NULL ORDER BY p.id_product_type DESC,p.product_name ASC,p.size ASC, i.id_product_in DESC";
						  							else
												 		$sql="SELECT i.*,p.id_product_type,p.product_name,p.price_buy,p.price_sale,o.total_o FROM `product_in` i JOIN product p ON i.id_product=p.id_product LEFT JOIN (select sum(ou.quantity) as total_o,ou.id_product_in FROM `product_out` ou GROUP BY ou.id_product_in ) as o ON i.id_product_in=o.id_product_in WHERE i.quantity>o.total_o or o.total_o IS NULL ORDER BY p.id_product_type DESC,p.product_name ASC,p.size ASC, i.id_product_in DESC";
													
													try{
														$rs=mysql_db_query($db,$sql,$con);					  
																		
													}catch (Exception $e){
														//writeLog($e);
													}
												    while($row=mysql_fetch_array($rs)){ 
			  											if($id_product_in==$row['id_product_in']){
			  										?>
			  										<option value="<?php echo $row['id_product']."_".$row['id_product_in']."_".$row['product_code']."_".$row['size'];?>" selected><?php echo  $row['product_code']."-".$row['product_name']."-".$row['size']." (Giá nhập: ".$row['price_in'].", SLnhập: ".$row['quantity'].", SLxuất: ".$row['total_o'].", SL còn lại: ".intval($row['quantity']-$row['total_o']).")";?></option>
			  										<?php 
			  										$quantity_remain=intval($row['quantity']-$row['total_o']);
			  										$price_sale=$row['price_sale'];
			  										$price_in=$row['price_in'];
			  										$price_buy=$row['price_buy'];
			  											}else{
			  											?>
			  										<option <?php if ($id_product_in && $_GET["id"]) echo "disabled"; ?>  value="<?php echo $row['id_product']."_".$row['id_product_in']."_".$row['product_code']."_".$row['size'];?>"><?php echo  $row['product_code']."-".$row['product_name']."-".$row['size']." (Giá nhập: ".$row['price_in'].", SLnhập: ".$row['quantity'].", SLxuất: ".$row['total_o'].", SL còn lại: ".intval($row['quantity']-$row['total_o']).")";?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
			  							<?php 
			  							//echo $sql;
			  							
			  							/*if($id_product_in){
			  								$sql="SELECT i.*,o.total_o FROM `product_in` i LEFT JOIN (select sum(ou.quantity) as total_o,ou.id_product_in FROM `product_out` ou WHERE ou.id_product_in=".$id_product_in." GROUP BY ou.id_product_in ) as o ON i.id_product_in=o.id_product_in WHERE i.id_product_in=".$id_product_in." ORDER BY i.id_product_in DESC";
			  								//echo $sql;
											try{
												$rs=mysql_db_query($db,$sql,$con);
												$num_rows = mysql_num_rows($rs);					  
												if ($num_rows){
													//echo "row:".$num_rows;
													 
													 */	
										?>
										 <!-- <div class="row-fluid">
					                        <!-- block -->
					                        <!-- <div class="block">
					                            <div class="navbar navbar-inner block-header">
					                                <div class="muted pull-left">Thông tin nhập-xuất-còn lại</div>
					                            </div>
					                            <div class="block-content collapse in">
					                                <div class="span12">
					  									<table class="table">
											              <thead>
											                <tr>
											                  <th>Mã sản phẩm</th>
											                  <th>Kích cỡ</th>
											                  <th>Giá nhập</th>
											                  <th>Số lượng nhập</th>					                  
											                  <th>Đã xuất</th>
											                  <th>Còn lại</th>
											                </tr>
											              </thead>
											              <tbody> -->
											              <?php 
											              //while($row=mysql_fetch_array($rs)){
															//$quantity_remain=$row['quantity']-$row['total_u'];
											              ?>
											              
											                <!-- <tr>
											                  <td><?php //echo $row['product_code'];?></td>
											                  <td><?php //echo $row['size'];?></td>
											                  <td><?php //echo $row['price_in'];?></td>
											                  <td><?php //echo $row['quantity'];?></td>
											                  <td><?php //echo $row['total_o'];?></td>
											                  <td><?php //echo $quantity_remain;?></td>
											                </tr>											                
											                <?php //}//while?>
											              </tbody>
											            </table>
					                                </div>
					                            </div>
					                        </div>
					                       
					                    </div>
					                     -->
                    					<?php 													
											/*		}//num_row	
											}catch (Exception $e){
											  //writeLog($e);
											}
										}*/
										?>
                                        <div class="control-group">
                                          <label class="control-label" for="quantity">Số lượng xuất <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="quantity" value="<?php if($_GET["id"]) echo $quantity; else echo $quantity_remain;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="price_buy">Giá mua(theo bảng giá)</label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="price_buy" readonly value="<?php echo $price_buy;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="price_in">Giá nhập(thực tế nhập)</label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="price_in" readonly value="<?php echo $price_in;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="price_out">Giá xuất(theo bảng giá)<span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="price_out" value="<?php if($_GET["id"]) echo $price_out; else echo $price_sale;?>">                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="product_out_note">Chú thích</label>
                                          <div class="controls">
                                            <textarea name='product_out_note' rows="3" class="input-xlarge textarea" placeholder="Enter text ..." style="width: 90%;"><?php echo $product_out_note;?></textarea>
                                          </div>
                                        </div>                                      
                                       <div class="form-actions">
                                          <button type="submit" name="sm_1" value="1" class="btn btn-primary">Save</button>
                                          <button type="submit" name="sm_2" value="1" class="btn btn-primary">Save and Close</button>
                                          <button type="reset" name="cc_1" value="1" class="btn">Reset</button>
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div>
 
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
        <script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>