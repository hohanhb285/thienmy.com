<!DOCTYPE html>
<html>
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
 <?php 
 if($_GET["id"]){
 	$sql="select * from product_order where id_product_order=".$_GET["id"];
	//echo $sql;
	$rse=mysql_db_query($db,$sql,$con);	
	$rowe=mysql_fetch_array($rse);
 	$id_product=$rowe["id_product"];
 	$id_customer=$rowe["id_customer"]; 	
	$product_code=$rowe["product_code"];
 	$size=$rowe["size"];
	$order_quantity=$rowe["order_quantity"];
	$price_sale=$rowe["price_sale"];
	$lack_quantity=$rowe["lack_quantity"];
	$product_order_note=$rowe["product_order_note"];
}
$id_product_type=$_POST["id_product_type"];
if(!$_GET["id"]){
  	if($_POST["id_product"]){
	 $arr_product=explode("_",$_POST["id_product"]);
	 $id_product=$arr_product[0];
	 $product_code=$arr_product[1];
	 $size=$arr_product[2];
 	}  	
 	$id_customer=$_POST["id_customer"];
 }
if($_POST["order_code"])
	$order_code=$_POST["order_code"];
if(!$order_code && $_GET["order_code"] && $_GET["order_code"]<>"Nhập mã ĐH cần tìm")
	$order_code=$_GET["order_code"];

if($_GET['flag']){
	$sql1="select o.id_customer from product_order o where o.order_code='".$order_code."' limit 0,1";
	$rs1=mysql_db_query($db,$sql1,$con);
    while($row1=mysql_fetch_array($rs1)) 
		$id_customer=$row1['id_customer'];	
 }

 if ($_POST["sm_1"] || $_POST["sm_2"]){ 
 	$order_code=$_POST["order_code"];	
	$order_quantity=intval($_POST["order_quantity"]);
	$vowels = array(",", ".");
	$price_sale=str_replace($vowels,'',$_POST["price_sale"]);	
	$product_order_note=$_POST["product_order_note"];
	$lack_quantity=$_POST["lack_quantity"];
	$created_datetime=date('Y-m-d H:m:s',time());
	if($_GET['flag'])
		$is_check=1;
	$sMesage='';
	 if($_GET["flag"] && $_POST['order_code']=='')   
	 	$sMesage="Bạn chưa nhập Mã đơn hàng cần thêm";
	 if($_POST["id_customer"]=='')   
	 	$sMesage.="<br>Bạn chưa chọn khách hàng";
	 if($_POST["id_product"]=='')   
	 	$sMesage.="<br>Bạn chưa chọn Sản phẩm cần đặt";	
	 //if($_POST["product_code"]=='')   
	 	//$sMesage.="<br>Bạn chưa nhập Mã sản phẩm";	
	 if($_POST["order_quantity"]==''||$_POST["order_quantity"]==0)   
	 	$sMesage.="<br>Bạn chưa nhập Số lượng cần đặt";
	 if($_POST["price_sale"]=='')   
	 	$sMesage.="<br>Bạn chưa nhập Giá bán";			
	 	
	try{
		if($sMesage==''){
			if($_GET["id"]){
					$sql="update product_order set order_quantity='$order_quantity',price_sale='$price_sale',lack_quantity='$lack_quantity',product_order_note='$product_order_note',updated_datetime='$created_datetime' where id_product_order=".$_GET["id"];					
			}else{
					$sql="insert into product_order(order_code,id_product,product_code,size,order_quantity,price_sale,id_customer,lack_quantity,product_order_note,is_check,updated_datetime,created_datetime) values ";
					$sql=$sql."('$order_code','$id_product','$product_code','$size','$order_quantity','$price_sale','$id_customer','$lack_quantity','$product_order_note','$is_check','$created_datetime','$created_datetime')";
				
			}
			//echo $sql;
			if (mysql_db_query($db,$sql,$con)){
				 $sMesage="Thao tác thành công";
				 if($_POST["sm_1"]){
				 	?>
				 	<script>refresh();</script>
				 	<?php
				 }else{
				 	?>
				 	<script>refreshAndClose();</script>
				 	<?php
				 }	 
			 }else{
				 $sMesage="Thao tác không thành công"; 		 
		     }
		     
		}
	}catch (Exception $e){
		//writeLog($e);
	}
     
 }
 ?>
    <body>
        <?php //include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php //include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid" >
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Đặt hàng cho khách hàng</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <form class="form-horizontal" id="frm_1"  method="post" enctype="multipart/form-data">
                                      <fieldset>
                                        <div class="control-group error" style="text-align: center">
                                          <label class="control-label" for="inputError" style="padding-left:22%;width:50%;text-align:left"><?php echo $sMesage; ?></label>
                                        </div>
                                        <?php if($_GET['flag']){?>
                                        <div class="control-group">
                                          <label class="control-label" for="order_code">Mã đặt hàng <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="order_code" value="<?php echo $order_code;?>">                                            
                                          </div>
                                        </div>
                                        <?php } ?>
                                        <div class="control-group">
			  								<label class="control-label">Khách hàng<span class="required">*</span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_customer"  <?php if ($id_customer && $_GET["id"]) echo "readonly"; ?>>
			  										<option <?php if ($id_customer && $_GET["id"]) echo "disabled"; ?> value="">Chọn khách hàng...</option>
			  										<?php 
												 	$sql="select * from customer order by id_customer desc";
													//echo $sql;
													try{
														$rs=mysql_db_query($db,$sql,$con);					  
																		
													}catch (Exception $e){
														//writeLog($e);
													}
												    while($row=mysql_fetch_array($rs)){ 
			  											if($id_customer==$row['id_customer']){
			  										?>
			  										<option value="<?php echo $row['id_customer'];?>" selected><?php echo  $row['id_customer']."-".$row['agent_name']." - ".$row['fullname']." - ".$row['phone'];?></option>
			  										<?php 
			  											}else{
			  											?>
			  										<option <?php if ($id_customer && $_GET["id"]) echo "disabled"; ?> value="<?php echo $row['id_customer'];?>"><?php echo  $row['id_customer']."-".$row['agent_name']." - ".$row['fullname']." - ".$row['phone'];?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
                                        <div class="control-group">
			  								<label class="control-label">Loại sản phẩm<span class="required"></span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_product_type" onchange="this.form.submit()">
			  											<option value="">Chọn loại...</option>
			  										<?php 
												 	$sql="select * from product_type order by id_product_type desc";
													//echo $sql;
													try{
														$rs=mysql_db_query($db,$sql,$con);					  
																		
													}catch (Exception $e){
														//writeLog($e);
													}
												    while($row=mysql_fetch_array($rs)){ 
			  											if($id_product_type==$row['id_product_type']){
			  										?>
			  										<option value="<?php echo $row['id_product_type'];?>" selected><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
			  										<?php 
			  											}else{
			  											?>
			  										<option value="<?php echo $row['id_product_type'];?>"><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
			  							
                                        <div class="control-group">
			  								<label class="control-label">Sản phẩm<span class="required">*</span></label>
			  								<div class="controls">
			  									<select class="span6 m-wrap" name="id_product" onchange="this.form.submit()" <?php if ($id_product && $_GET["id"]) echo "readonly"; ?>>
			  										<option <?php if ($id_product && $_GET["id"]) echo "disabled"; ?> value="">Chọn sản phẩm...</option>
			  										<?php 
						  							if($_POST['id_product_type'])
						  								$sql="SELECT p.* FROM `product` p WHERE p.id_product_type=".$_POST['id_product_type']." ORDER BY p.id_product_type DESC,p.product_name ASC,p.size ASC";
						  							else
						  								$sql="SELECT p.* FROM `product` p ORDER BY p.id_product_type DESC,p.product_name ASC,p.size ASC";
													
													try{
														$rs=mysql_db_query($db,$sql,$con);					  
																		
													}catch (Exception $e){
														//writeLog($e);
													}
												    while($row=mysql_fetch_array($rs)){ 												    	
			  											if($id_product==$row['id_product']){
			  										?>
			  										<option value="<?php echo $row['id_product']."_".$row['product_code']."_".$row['size'];?>" selected><?php echo  $row['product_code']."-".$row['product_name']."-".$row['size']." (Giá xuất: ".$row['price_sale'].")";?></option>
			  										<?php
			  											$price_sale=$row['price_sale'];
			  											}else{
			  											?>
			  											<option <?php if ($id_product && $_GET["id"]) echo "disabled"; ?> value="<?php echo $row['id_product']."_".$row['product_code']."_".$row['size'];?>"><?php echo  $row['product_code']."-".$row['product_name']."-".$row['size']." (Giá xuất: ".$row['price_sale'].")";?></option>
			  										<?php	
			  											}
			  											}?>
			  										
			  									</select>
			  								</div>
			  							</div>
			  							
                                        <div class="control-group">
                                          <label class="control-label" for="order_quantity">Số lượng đặt <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="order_quantity" value="<?php echo $order_quantity;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="price_sale">Giá bán <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="price_sale" value="<?php echo $price_sale;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="lack_quantity">Số lượng thiếu <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="lack_quantity" value="<?php echo $lack_quantity;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="product_order_note">Chú thích</label>
                                          <div class="controls">
                                            <textarea name='product_order_note' rows="3" class="input-xlarge textarea" placeholder="Enter text ..." style="width: 90%;"><?php echo $product_order_note;?></textarea>
                                          </div>
                                        </div>                                      
                                       <div class="form-actions">
                                          <button type="submit" name="sm_1" value="1" class="btn btn-primary">Save</button>
                                          <button type="submit" name="sm_2" value="1" class="btn btn-primary">Save and Close</button>
                                          <button type="reset" name="cc_1" value="1" class="btn">Reset</button>
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div>
 
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
        <script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>