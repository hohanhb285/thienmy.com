<!DOCTYPE html>
<html>
    
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
    
    <body>
        <?php include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid">
                        <!-- block -->
                            <div class="navbar navbar-inner block-header">
                            	<form class="form-horizontal" id="frm_1" style="padding-left:10px"  method="post" enctype="multipart/form-data">
	                                <div class="muted pull-left"  style="float: left;">Danh sách sản phầm còn hàng</div>
	                                <div class="controls" style="padding-top:5px;width:500px;float:left">
	  									<select class="span6 m-wrap" name="id_product_type" onchange="this.form.submit()" >
	  										<option value="">Chọn loại sản phẩm cần tìm...</option>
	  										<?php 
										 	$sql="select * from product_type order by id_product_type desc";
											//echo $sql;
											try{
												$rs=mysql_db_query($db,$sql,$con);					  
																
											}catch (Exception $e){
												//writeLog($e);
											}
											$id_product_type=$_POST['id_product_type'];
										    while($row=mysql_fetch_array($rs)){ 
	  											if($id_product_type==$row['id_product_type']){
	  										?>
	  										<option value="<?php echo $row['id_product_type'];?>" selected><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
	  										<?php 
	  											}else{
	  											?>
	  										<option value="<?php echo $row['id_product_type'];?>"><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
	  										<?php	
	  											}
	  											}?>
	  										
	  									</select>
	  								</div>
	  								<div class="btn-group pull-right" style="padding-top:0px;float: right;">
	                                  <button style="padding-top:0px;float: right;" data-toggle="dropdown" class="btn dropdown-toggle">Export <span class="caret"></span></button>
	                                         <ul class="dropdown-menu" style="padding-top:0px;float: right;">
	                                            <!--<li><a href="#">Print</a></li>
	                                            <li><a href="#">Save as PDF</a></li>-->
	                                            <li><a href="product_export_excel_xlsx.php">Export to Excel</a></li>
	                                         </ul>
	                                </div>
                                </form>
                            </div>
                            
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example22">
                                        <thead>
                                            <tr>
                                                <th>STT</th>
                                                <th>Mã sản phẩm</th>
                                                <th>Tên sản phẩm</th>
                                                <th>Kích cỡ</th>
                                                <th>Loại sản phẩm</th>
                                                <th>SL nhập</th>
                                                <th>SL xuất</th>
                                                <th>SL còn lại</th>                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php 
                                        if($_POST["id_product_type"])
                                        	$sql="SELECT i.*,p.id_product_type,t.product_type_name,p.product_name,p.price_sale,o.total_o FROM `product_in` i JOIN product p ON i.id_product=p.id_product JOIN product_type t ON p.id_product_type=t.id_product_type AND p.id_product_type=".$id_product_type." LEFT JOIN (select sum(ou.quantity) as total_o,ou.id_product_in FROM `product_out` ou GROUP BY ou.id_product_in ) as o ON i.id_product_in=o.id_product_in WHERE i.quantity>o.total_o or o.total_o IS NULL ORDER BY p.id_product_type DESC,p.product_name ASC,p.size ASC, i.id_product_in DESC";
                                        else
                                        	$sql="SELECT i.*,p.id_product_type,t.product_type_name,p.product_name,p.price_sale,o.total_o FROM `product_in` i JOIN product p ON i.id_product=p.id_product JOIN product_type t ON p.id_product_type=t.id_product_type LEFT JOIN (select sum(ou.quantity) as total_o,ou.id_product_in FROM `product_out` ou GROUP BY ou.id_product_in ) as o ON i.id_product_in=o.id_product_in WHERE i.quantity>o.total_o or o.total_o IS NULL ORDER BY p.id_product_type DESC,p.product_name ASC,p.size ASC, i.id_product_in DESC";	
										//echo "Here:".$sql;
										try{
											$rs=mysql_db_query($db,$sql,$con);					  
														
										}catch (Exception $e){
											//writeLog($e);
										}
                                        $i=0;
                                        while($row=mysql_fetch_array($rs)){
                                        	$i++;
                                        	$quantity_store=$row['quantity']-$row['total_o'];
                                        	if($i%2){
                                        ?>
                                            <tr class="even gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td><?php echo $row['product_type_name'];?></td>
                                                <td><?php echo $row['quantity'];?></td>  
                                                <td><?php echo $row['total_o'];?></td> 
                                                <td><?php echo $quantity_store;?></td>                                                 
                                             </tr>
                                            <?php }else{ ?>
                                            <tr class="odd gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td><?php echo $row['product_type_name'];?></td>
                                                <td><?php echo $row['quantity'];?></td>  
                                                <td><?php echo $row['total_o'];?></td> 
                                                <td><?php echo $quantity_store;?></td> 
                                            </tr>                                           
                                        <?php 
                                            }
                                        }
                                        ?>                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div> 
        <!--/.fluid-container-->
        
        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>