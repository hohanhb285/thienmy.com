<!DOCTYPE html>
<html>
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
 <?php 
 if($_GET["id"]){
 	$sql="select * from expense where id_expense=".$_GET["id"];
	//echo $sql;
	$rse=mysql_db_query($db,$sql,$con);	
	$rowe=mysql_fetch_array($rse);
 	$bill_code=$rowe["bill_code"]; 	
	$expense_name=$rowe["expense_name"];
 	$expense_value=$rowe["expense_value"];
	$expense_note=$rowe["expense_note"];
}
if($_GET["bill_code"] && $_GET["bill_code"]<>"Nhập mã ĐH cần tìm")
	$bill_code=$_GET["bill_code"];
	
if ($_POST["sm_1"] || $_POST["sm_2"]){ 	
	$bill_code=$_POST["bill_code"];
	$expense_name=$_POST["expense_name"];
	$vowels = array(",", ".");
	$expense_value=str_replace($vowels,'',$_POST["expense_value"]);	
	$expense_note=$_POST["expense_note"];
	$created_datetime=date('Y-m-d H:m:s',time());
	$sMesage='';
	 if($_POST["bill_code"]=='')   
	 	$sMesage="Bạn nhập Mã đơn hàng cần nhập chi phí";
	 if($_POST["expense_name"]=='')   
	 	$sMesage.="<br>Bạn chưa Tên chi phí";	
	 if($_POST["expense_value"]=='')   
	 	$sMesage.="<br>Bạn chưa nhập Chi phí";
	 	
	try{
		if($sMesage==''){
			if($_GET["id"]){
					$sql="update expense set expense_name='$expense_name',expense_value='$expense_value',expense_note='$expense_note',updated_datetime='$created_datetime' where id_expense=".$_GET["id"];					
			}else{
					$sql="insert into expense(bill_code,expense_name,expense_value,expense_note,updated_datetime,created_datetime) values ";
					$sql=$sql."('$bill_code','$expense_name','$expense_value','$expense_note','$created_datetime','$created_datetime')";
			}
			//echo $sql;
			if (mysql_db_query($db,$sql,$con)){
				//Calc expense sum
				$sql_s="update bill set expense=(select sum(expense_value) from expense where bill_code=".$bill_code." group by bill_code) where bill_code=".$bill_code;
				$rs_s=mysql_db_query($db,$sql_s,$con);
				//End calc expense sum
				 $sMesage="Thao tác thành công";
				 if($_POST["sm_1"]){
				 	?>
				 	<script>refresh();</script>
				 	<?php
				 }else{
				 	?>
				 	<script>refreshAndClose();</script>
				 	<?php
				 }	 
			 }else{
				 $sMesage="Thao tác không thành công"; 		 
		     }
		     
		}
	}catch (Exception $e){
		//writeLog($e);
	}
     
 }
 ?>
    <body>
        <?php //include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php //include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid" >
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Chi phí</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <form class="form-horizontal" id="frm_1"  method="post" enctype="multipart/form-data">
                                      <fieldset>
                                        <div class="control-group error" style="text-align: center">
                                          <label class="control-label" for="inputError" style="padding-left:22%;width:50%;text-align:left"><?php echo $sMesage; ?></label>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="bill_code">Mã đơn hàng <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="bill_code" value="<?php echo $bill_code;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="expense_name">Tên chi phí <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="expense_name" value="<?php echo $expense_name;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="expense_value">Chi phí <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="expense_value" value="<?php echo $expense_value;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="expense_note">Chú thích</label>
                                          <div class="controls">
                                            <textarea name='expense_note' rows="3" class="input-xlarge textarea" placeholder="Enter text ..." style="width: 90%;"><?php echo $expense_note;?></textarea>
                                          </div>
                                        </div>                                      
                                       <div class="form-actions">
                                          <button type="submit" name="sm_1" value="1" class="btn btn-primary">Save</button>
                                          <button type="submit" name="sm_2" value="1" class="btn btn-primary">Save and Close</button>
                                          <button type="reset" name="cc_1" value="1" class="btn">Reset</button>
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div>
 
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
        <script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>