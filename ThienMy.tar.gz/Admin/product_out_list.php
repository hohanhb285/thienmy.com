<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
    
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
    <?php 
    if($_GET["iddel"]){
    	$sql="delete from product_out where id_product_out=".$_GET["iddel"];
    	mysql_db_query($db,$sql,$con);
    }
    ?>
    <body>
        <?php include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid">
                        <!-- block -->
                        <form class="form-horizontal" id="frm_1"  method="post" enctype="multipart/form-data">
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Danh sách xuất hàng</div>
                                <div class="controls" style="padding-left:50px;padding-top:5px;width:500px;float:left">
	  									<select class="span6 m-wrap" name="id_customer" onchange="this.form.submit()" >
	  										<option value="-1">Chọn khách hàng đã xuất...</option>
	  										<?php 
										 	$sql="select * from customer where fullname<>'' or fullname is not NULL order by id_customer desc";
											//echo $sql;
											try{
												$rs=mysql_db_query($db,$sql,$con);					  
																
											}catch (Exception $e){
												//writeLog($e);
											}
											if($_POST['id_customer'])
												$id_customer=$_POST['id_customer'];
											else
												$id_customer=$_GET['id_customer'];	
										    while($row=mysql_fetch_array($rs)){ 
										    	if($row['fullname'])
										    		$customer_contact=$row['id_customer']."-".$row['agent_name']." - ".$row['fullname']." - ".$row['phone'];
										    	else
										    		$customer_contact=$row['id_customer']."-".$row['agent_name']." - ".$row['phone'];
	  											if($id_customer==$row['id_customer']){
	  										?>
	  										<option value="<?php echo $row['id_customer'];?>" selected><?php echo  $customer_contact;?></option>
	  										<?php 
	  											}else{
	  											?>
	  										<option value="<?php echo $row['id_customer'];?>"><?php echo  $customer_contact;?></option>
	  										<?php	
	  											}
	  											}?>
	  										
	  									</select>
	  								</div>
                                      <div class="btn-group pull-right" style="padding-top:1px">
                                      	<a href="#" onclick="javascript: openPopUp('product_out_add.php','Nhập hàng',860,680);"><button class="btn btn-success">Xuất hàng <i class="icon-plus icon-white"></i></button></a>
                                         <button data-toggle="dropdown" class="btn dropdown-toggle">Export <span class="caret"></span></button>
                                         <ul class="dropdown-menu">
                                            <!--<li><a href="#">Print</a></li>
                                            <li><a href="#">Save as PDF</a></li>-->
                                            <li><a href="product_export_excel_xlsx.php">Export to Excel</a></li>
                                         </ul>
                                      </div>
                                 
                            </div>
                            
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
                                        <thead>
                                            <tr>
                                                <th>STT</th>
                                                <th>Mã ĐH</th>
                                                <th>Mã xuất</th>
                                                <th>Mã nhập</th>
                                                <th>Mã sản phẩm</th>
                                                <th>Tên sản phẩm</th>
                                                <th>Kích cỡ</th>
                                                <th>Mã KH</th>                                                
                                                <th>SL xuất</th>
                                                <th>Giá nhập</th>
                                                <th>Giá xuất</th>
                                                <th>Thành tiền nhập</th>
                                                <th>Thành tiền xuất</th>
                                                <th>Chú thích</th>                                                
                                                <th>Thao tác</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        if($id_customer>0) 
                                        	$sql="select o.*, p.product_name from product_out o, product p where o.id_product=p.id_product and o.id_customer=".$id_customer." and o.status=0 order by o.id_product_out desc";
                                        else
                                        	$sql="select o.*, p.product_name from product_out o, product p where o.id_product=p.id_product and o.status=0 order by o.id_product_out desc";	
										//echo $sql;
										try{
											$rs=mysql_db_query($db,$sql,$con);					  
															
										}catch (Exception $e){
											//writeLog($e);
										}
										
										$i=0;
                                        $receipt=0;
                                        $price_purchase=0;
                                        $bill_code_edit="";
                                        while($row=mysql_fetch_array($rs)){
                                        	$i++;
                                        	$Thanh_tien_nhap=$row['price_in']*$row['quantity'];
                                        	$price_purchase+=$Thanh_tien_nhap;
                                        	$Thanh_tien_xuat=$row['price_out']*$row['quantity'];
                                        	$receipt+=$Thanh_tien_xuat;
                                        	if($row['bill_code'])
                                        		$bill_code_edit=$row['bill_code'];
                                        	if(!$_POST['sm_3']){
                                        		if($i%2){
                                        ?>
                                            <tr class="even gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['bill_code'];?></td>
                                                <td><?php echo $row['id_product_out'];?></td>
                                                <td><?php echo $row['id_product_in'];?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td><a href="#" onclick="javascript: openPopUp('customer_list.php?idview=<?php echo $row['id_customer'];?>','Khách hàng',850,600);"><?php echo $row['id_customer'];?></a></td>
                                                <td><?php echo $row['quantity'];?></td>  
                                                <td class="center"><?php echo number_format($row['price_in']);?></td>                                              
                                                <td class="center"><?php echo number_format($row['price_out']);?></td>
                                                <td class="center"><?php echo number_format($Thanh_tien_nhap);?></td>
                                                <td class="center"><?php echo number_format($Thanh_tien_xuat);?></td>
                                                <td class="center"><?php echo $row['product_out_note'];?></td>                                              
                                                <td class="center"><a href="#" onclick="javascript: openPopUp('product_out_add.php?id=<?php echo $row["id_product_out"];?>','Sản phẩm',1000,650);">Sửa</a> - <a href="product_out_list.php?iddel=<?php echo $row["id_product_out"].'&id_customer='.$id_customer;?>" onClick="return del();">Xóa</a></td>
                                            </tr>
                                            <?php }else{ ?>
                                            <tr class="odd gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['bill_code'];?></td>
                                                <td><?php echo $row['id_product_out'];?></td>
                                                <td><?php echo $row['id_product_in'];?></td>                                                
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>                                                
                                                <td><?php echo $row['size'];?></td>
                                                <td><a href="#" onclick="javascript: openPopUp('customer_list.php?idview=<?php echo $row['id_customer'];?>','Khách hàng',1000,600);"><?php echo $row['id_customer'];?></a></td>
                                                <td><?php echo $row['quantity'];?></td>   
                                                <td class="center"><?php echo number_format($row['price_in']);?></td>                                              
                                                <td class="center"><?php echo number_format($row['price_out']);?></td>
                                                <td class="center"><?php echo number_format($Thanh_tien_nhap);?></td>
                                                <td class="center"><?php echo number_format($Thanh_tien_xuat);?></td>
                                                <td class="center"><?php echo $row['product_out_note'];?></td>                                         
                                                <td class="center"><a href="#" onclick="javascript: openPopUp('product_out_add.php?id=<?php echo $row["id_product_out"];?>','Sản phẩm',850,650);">Sửa</a> - <a href="product_out_list.php?iddel=<?php echo $row["id_product_out"].'&id_customer='.$id_customer;?>" onClick="return del();">Xóa</a></td>
                                            </tr>                                           
                                        <?php 
                                            }
                                         }//end if $_POST['sm_3']
                                        } //end while 
                                        
                                        if($id_customer && $receipt<>0){
                                        	?>
                                        	<tr class="even gradeA">
                                                <td><strong><?php echo "Total";?></strong></td>
                                                <td><?php //echo $row['bill_code'];?></td>
                                                <td><?php //echo $row['id_product_out'];?></td>
                                                <td><?php //echo $row['id_product_in'];?></td>
                                                <td><?php //echo $row['product_code'];?></td>
                                                <td><?php //echo $row['product_name'];?></td>
                                                <td><?php //echo $row['size'];?></td>
                                                <td></td>
                                                <td><?php //echo $row['quantity'];?></td>   
                                                <td class="center"><?php //echo $price_in;?></td>                                             
                                                <td class="center"><?php //echo $price_out;?></td>
                                                <td class="center"><strong><?php echo number_format($price_purchase);?></strong></td>
                                                <td class="center"><strong><?php echo number_format($receipt);?></strong></td>
                                                <td class="center"><?php //echo $row['product_out_note'];?></td>                                               
                                                <td class="center"><button type="submit" name="sm_3" value="1" class="btn btn-primary">Xuất đơn hàng</button></td>
                                            </tr>
                                        	<?php                                        	
                                        }
                                       // Update bill_code to product_out
                                        if($_POST['sm_3'] && $id_customer){
                                        	if($_SESSION['id_customer']<>$id_customer){
                                        		$_SESSION['id_customer']=$id_customer;
                                        		$_SESSION['bill_code']=substr(time(),-4);
                                        	}
                                        	$sql_bill="update product_out set bill_code='".$_SESSION['bill_code']."', status=1 where status=0 and id_customer=".$id_customer;
                                        	//echo $sql_bill;
                                        	mysql_db_query($db,$sql_bill,$con);
                                        }
                                        // End Update bill_code to product_out                              	                                 
                                        
                                        
                                        // Create bill
                                        	if($_POST['sm_3'] && $id_customer){
                                        		if($receipt<>0){
                                        			
											    	$sql="delete from bill where bill_code=".$_SESSION['bill_code']." and id_customer=".$id_customer;
											    	mysql_db_query($db,$sql,$con);
											    	
											    	$sql_ex="select sum(expense_value) as expense_sum from expense where bill_code=".$_SESSION['bill_code']." group by bill_code";
											    	$rs_ex=mysql_db_query($db,$sql_ex,$con);
											    	$expense_sum=0;
											    	while($row_ex=mysql_fetch_array($rs_ex)){
											    		$expense_sum=$row_ex['expense_sum'];
											    	}
											    	
											    	$created_datetime=date('Y-m-d H:m:s',time());
											    	$sql="insert into bill(bill_code,id_customer,receipt,price_purchase,expense,updated_datetime,created_datetime) values ";
													$sql=$sql."('".$_SESSION['bill_code']."','$id_customer','$receipt','$price_purchase','$expense_sum','$created_datetime','$created_datetime')";
													mysql_db_query($db,$sql,$con);
													
													$_SESSION['id_customer']='';
                                        		}
										    }             
										    // End create bill 
                                        ?>                                        
                                        </tbody>
                                    </table>
                                    <div style="text-align: center;"><strong><?php if($_POST['sm_3'] && $_SESSION['bill_code']) echo "Mã ĐH vừa xuất:".$_SESSION['bill_code']." .";?></strong> Sau khi xuất đơn hàng, đơn hàng sẽ chuyển sang <a href="bill_list.php"> Thống kê->Đơn hàng.</a></div>
                                </div>                                
                            </div>
                        </div>
                        <!-- /block -->
                        </form>
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div> 
        <!--/.fluid-container-->
        
        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>