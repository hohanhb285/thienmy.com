<!DOCTYPE html>
<html>
    
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <script type="text/javascript" src="lib/jsPDF-master/js/jquery/jquery-1.7.1.min.js"></script>
    	<script type="text/javascript" src="lib/jsPDF-master/js/jquery/jquery-ui-1.8.17.custom.min.js"></script>
    	<script type="text/javascript" src="lib/jsPDF-master/dist/jspdf.debug.js"></script>
    	<script type="text/javascript" src="lib/jsPDF-master/js/basic.js"></script>
    </head>
    <script src="lib/common.js"></script>
    <body>
    	<?php $SESSION['id_customer']=$_GET['id_customer'];?>
        <?php include_once("bill_top.php");?>
        <div class="container-fluid" style="padding-top:60px">
            <div class="row-fluid" id="content_need_save">
                <?php include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Danh sách đơn hàng</div>
                                      <div class="btn-group pull-right" style="padding-top:1px">
                                      	 <button onClick="window.print()" data-toggle="dropdown" class="btn dropdown-toggle">Print <span class="caret"></span></button>                                         
                                      </div>
                            </div>
                            
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
                                        <thead>
                                            <tr>
                                                <th>STT</th>
                                                <th>Mã sản phẩm</th>
                                                <th>Tên sản phẩm</th>
                                                <th>Kích cỡ</th>
                                                <th>Số lượng</th>
                                                <th>Giá </th>
                                                <th>Thành tiền</th>
                                                <th>Chú thích</th>
                                             </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $bill_code=$_GET['bill_code'];
                                        $sql="select o.*, p.product_name from product_out o, product p where o.id_product=p.id_product and o.bill_code=".$bill_code." order by o.id_product_out desc";
                                        //echo $sql;
										try{
											$rs=mysql_db_query($db,$sql,$con);					  
															
										}catch (Exception $e){
											//writeLog($e);
										}
                                        $i=0;
                                        while($row=mysql_fetch_array($rs)){
                                        	$i++;
                                        	$Thanh_tien=$row['price_out']*$row['quantity'];
                                        	$Thanh_tien_total+=$Thanh_tien;
                                        	                                        	
                                        	if($i%2){
                                        ?>
                                            <tr class="even gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td><?php echo $row['quantity'];?></td>                                                
                                                <td class="center"><?php echo number_format($row['price_out']);?></td>
                                                <td class="center"><?php echo number_format($Thanh_tien);?></td>
                                                <td class="center"><?php echo $row['product_out_note'];?></td>                                                
                                            </tr>
                                            <?php }else{ ?>
                                            <tr class="even gradeC">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td><?php echo $row['quantity'];?></td>                                                
                                                <td class="center"><?php echo number_format($row['price_out']);?></td>
                                                <td class="center"><?php echo number_format($Thanh_tien);?></td>
                                                <td class="center"><?php echo $row['product_out_note'];?></td>                                                
                                            </tr>                                          
                                        <?php 
                                            }
                                        }                                      
                                        ?>
                                        	<tr class="even gradeA">
                                                <td><strong><?php echo "Tổng tiền:";?></strong></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td class="center"><strong><?php echo number_format($Thanh_tien_total);?></strong></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("bill_footer.php");?>
            </footer>
        </div> 
        
    </body>

</html>