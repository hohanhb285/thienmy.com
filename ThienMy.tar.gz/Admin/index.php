<!DOCTYPE html>
<html>
    
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <?php 
 
 if ($_POST["sm_1"]){
 	
	$product_type_code=$_POST["product_type_code"];
	$product_type_name=$_POST["product_type_name"];
	$product_type_note=$_POST["product_type_note"];
	$created_datetime=date('Y-m-d H:m:s',time());
		
	$sql="insert into product_type(product_type_code,product_type_name,product_type_note,updated_datetime,created_datetime) values ";
	$sql=$sql."('$product_type_code','$product_type_name','$product_type_note','$created_datetime','$created_datetime')";
	//echo $sql;
	try{
		if (mysql_db_query($db,$sql,$con)){
			 $sMesage="Nhập thành công";	 
		 }else{
			 $sMesage="Nhập không thành công"; 		 
	     }
	     if (substr(mysql_error(),0,9)=='Duplicate'){
	     	 $sMesage="Mã này đã tồn tại. Vui lòng nhập mã khác.";
	     }
	}catch (Exception $e){
		//writeLog($e);
	}
     
 }
 ?>
    <body>
        <?php include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("left.php");?>                
                <div class="span9" id="content" >
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid" >
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Nhập loại sản phẩm</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <form class="form-horizontal" id="frm_1"  method="post">
                                      <fieldset>
                                        <div class="control-group error" style="text-align: center">
                                          <label class="control-label" for="inputError" style="width:50%"><?php echo $sMesage; ?></label>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="product_type_code">Mã loại </label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="product_type_code" >                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="product_type_name">Tên loại </label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="product_type_name" >                                            
                                          </div>
                                        </div>                                        
                                        <div class="control-group">
                                          <label class="control-label" for="product_type_note">Chú thích</label>
                                          <div class="controls">
                                            <textarea name='product_type_note' rows="3" class="input-xlarge textarea" placeholder="Enter text ..." style="width: 90%;"></textarea>
                                          </div>
                                        </div>                                      
                                       <div class="form-actions">
                                          <button type="submit" name="sm_1" value="1" class="btn btn-primary">Save changes</button>
                                          <button type="reset" name="cc_1" value="1" class="btn">Cancel</button>
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div>
 
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
        <script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>