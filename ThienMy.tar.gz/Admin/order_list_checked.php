<!DOCTYPE html>
<html>
    
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
    <?php 
    if($_GET["iddel"]){
    	$sql="delete from product_order where id_product_order=".$_GET["iddel"];
    	mysql_db_query($db,$sql,$con);
    }
    
    ?>
    <body>
        <?php include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                            <form class="form-horizontal" id="frm_1"  method="post" enctype="multipart/form-data">
                                <div class="muted pull-left" style="padding-left:0px;padding-top:5px;width:250px">Danh sách khách hàng đặt(đã verify)</div>
                                <div class="controls" style="padding-left:0px;padding-top:5px;width:680px;float:left">
	  									<select class="span6 m-wrap" name="id_customer" onchange="this.form.submit()" style="width:250px">
	  										<option value="-1">Chọn khách hàng...</option>
	  										<?php 
	  										if($_POST['id_customer'])
												$id_customer=$_POST['id_customer'];
											else
												$id_customer=$_GET['id_customer'];
												
											$txt_order_code=$_POST['txt_order_code'];
											if(!$txt_order_code)
												$txt_order_code="Nhập mã ĐH cần tìm";
											
											$chk_lack=$_POST['chk_lack'];
											//echo "Lack:".$chk_lack;		
	  										$sql="select * from customer where id_customer in (select o.id_customer from product_order o where o.is_check=1) order by id_customer desc";
											//echo $sql;
											try{
												$rs=mysql_db_query($db,$sql,$con);					  
																
											}catch (Exception $e){
												//writeLog($e);
											}
											while($row=mysql_fetch_array($rs)){ 
										    	if($row['fullname'])
										    		$customer_contact=$row['id_customer']."-".$row['agent_name']." - ".$row['fullname']." - ".$row['phone'];
										    	else
										    		$customer_contact=$row['id_customer']."-".$row['agent_name']." - ".$row['phone'];
	  											if($id_customer==$row['id_customer']){
	  										?>
	  										<option value="<?php echo $row['id_customer'];?>" selected><?php echo  $customer_contact;?></option>
	  										<?php 
	  											}else{
	  											?>
	  										<option value="<?php echo $row['id_customer'];?>"><?php echo  $customer_contact;?></option>
	  										<?php	
	  											}
	  											}?>
	  										
	  									</select>
	  									<input type="text" name="txt_order_code" value="<?php echo $txt_order_code;?>" onfocus="this.select();" onmouseup="return false;">
	  									Xem thiếu hàng: 
	  									<input type="checkbox" name="chk_lack" <?php if($chk_lack) echo "checked"; ?> onchange="this.form.submit()">
	  								</div>
	  								</form>
                                      <div class="btn-group pull-right" style="padding-top:1px">
                                      	<a href="#" onclick="javascript: openPopUp('order_list_new_add.php?flag=1&order_code=<?php echo $txt_order_code;?>','Nhập sản phẩm',850,650);"><button class="btn btn-success">Thêm <i class="icon-plus icon-white"></i></button></a>
                                         <button data-toggle="dropdown" class="btn dropdown-toggle">Export <span class="caret"></span></button>
                                         <ul class="dropdown-menu">
                                            <!--<li><a href="#">Print</a></li>
                                            <li><a href="#">Save as PDF</a></li>-->
                                            <li><a href="product_export_excel_xlsx.php">Export to Excel</a></li>
                                         </ul>
                                      </div>
                                 
                            </div>
                            
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
                                        <thead>
                                            <tr>
                                                <th>STT</th>
                                                <th>Mã đặt hàng</th>
                                                <th>Mã sản phẩm</th>
                                                <th>Tên sản phẩm</th>
                                                <th>Kích cỡ</th>
                                                <th>Số lượng đặt</th>
                                                <th>Giá bán</th>
                                                <th>Thành tiền</th>
                                                <th>Thiếu</th>
                                                <th>Chú ý</th>
                                                <th>Ngày đặt</th>
                                                <th>Thao tác</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php 
                                        if($id_customer>0)
                                        	if($txt_order_code && $txt_order_code<>"Nhập mã ĐH cần tìm") 
									 			$sql="select o.*,p.product_name from product_order o, product p where o.is_check=1 and o.id_product=p.id_product and o.id_customer=".$id_customer." and o.order_code=".$txt_order_code;
											else
									 			$sql="select o.*,p.product_name from product_order o, product p where o.is_check=1 and o.id_product=p.id_product and o.id_customer=".$id_customer;
									 	else
									 		if($txt_order_code && $txt_order_code<>"Nhập mã ĐH cần tìm") 
									 			$sql="select o.*,p.product_name from product_order o, product p where o.is_check=1 and o.id_product=p.id_product and o.order_code=".$txt_order_code;	
									 		else	
									 			$sql="select o.*,p.product_name from product_order o, product p where o.is_check=1 and o.id_product=p.id_product";
										
									 	$sql_order_by=" order by p.id_product_type DESC,p.product_name ASC,p.id_product DESC,o.id_product_order DESC";
									 	if($chk_lack)
									 		$sql=$sql." and lack_quantity>0".$sql_order_by;
									 	else
									 		$sql=$sql.$sql_order_by;
									 	//echo $sql;
										try{
											$rs=mysql_db_query($db,$sql,$con);					  
															
										}catch (Exception $e){
											//writeLog($e);
										}
                                        $i=0;
                                        while($row=mysql_fetch_array($rs)){
                                        	$i++;
                                        	$arr_updated_datetime=explode(" ",$row['updated_datetime']);
                                        	$arr_updated_date=explode("-",$arr_updated_datetime[0]);                                        	
                                        	$updated_date=$arr_updated_date[2]."-".$arr_updated_date[1]."-".$arr_updated_date[0]." ".$arr_updated_datetime[1];
                                        	$order_quantity=$row['order_quantity'];
                                        	$price_sale=$row['price_sale'];
                                        	$ThanhTien=$order_quantity*$price_sale;
                                        	$ThanhTien_Sum+=$ThanhTien;
                                        	$product_order_note=$row['product_order_note'];
                                        	if($row['bill_code'])
                                        		$order_code_edit=$row['order_code'];
                                        	
                                        	if($i%2){
                                        ?>
                                            <tr class="even gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['order_code'];?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td class="center"><?php echo number_format($order_quantity);?></td>                                                
                                                <td class="center"><?php echo number_format($price_sale);?></td>
                                                <td class="center"><?php echo number_format($ThanhTien);?></td>
                                                <td class="center"><?php if($row['lack_quantity']) echo number_format($row['lack_quantity']);?></td>
                                                <td><?php echo $row['product_order_note'];?></td>
                                                <td class="center"><?php echo $updated_date;?></td>
                                                <td class="center"><a href="#" onclick="javascript: openPopUp('order_list_new_add.php?id=<?php echo $row["id_product_order"];?>','Sản phẩm',850,600);">Sửa</a> - <a href="order_list_new.php?iddel=<?php echo $row["id_product_order"].'&id_customer='.$id_customer;?>" onClick="return del();">Xóa</a></td>
                                            </tr>
                                            <?php }else{ ?>
                                            <tr class="odd gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['order_code'];?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td class="center"><?php echo number_format($order_quantity);?></td>                                                
                                                <td class="center"><?php echo number_format($price_sale);?></td>
                                                <td class="center"><?php echo number_format($ThanhTien);?></td>
                                                <td class="center"><?php if($row['lack_quantity']) echo number_format($row['lack_quantity']);?></td>
                                                <td><?php echo $row['product_order_note'];?></td>
                                                <td class="center"><?php echo $updated_date;?></td>
                                                <td class="center"><a href="#" onclick="javascript: openPopUp('order_list_new_add.php?id=<?php echo $row["id_product_order"];?>','Sản phẩm',850,600);">Sửa</a> - <a href="order_list_new.php?iddel=<?php echo $row["id_product_order"].'&id_customer='.$id_customer;?>" onClick="return del();">Xóa</a></td>
                                            </tr>                                           
                                        <?php 
                                            }
                                         }
                                        
                                        if($ThanhTien_Sum && $id_customer){
                                        ?>
                                        <tr class="odd gradeA">
                                                <td><strong><?php echo "Tổng tiền";?></strong></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>                                                
                                                <td></td>
                                                <td></td>
                                                <td class="center"><strong><?php echo number_format($ThanhTien_Sum);?></strong></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                         </tr>
                                         <?php } ?>
                                                                              
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                        
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div> 
        <!--/.fluid-container-->
        
        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>