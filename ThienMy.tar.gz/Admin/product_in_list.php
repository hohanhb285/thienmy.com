<!DOCTYPE html>
<html>
    
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
    <?php 
    if($_GET["iddel"]){
    	$sql="delete from product_in where id_product_in=".$_GET["iddel"];
    	mysql_db_query($db,$sql,$con);
    }
    
    ?>
    <body>
        <?php include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                            	<form class="form-horizontal" id="frm_1" style="padding-left:10px"  method="post" enctype="multipart/form-data">
                                <div class="muted pull-left">Danh sách nhập hàng</div>
                                <div class="controls" style="padding-left:50px;padding-top:5px;width:500px;float:left">
	  									<select class="span6 m-wrap" name="id_product_type" onchange="this.form.submit()" >
	  										<option value="-1">Chọn loại sản phẩm...</option>
	  										<?php 
										 	$sql="select * from product_type order by id_product_type desc";
											//echo $sql;
											try{
												$rs=mysql_db_query($db,$sql,$con);					  
																
											}catch (Exception $e){
												//writeLog($e);
											}
											if($_POST['id_product_type'])
												$id_product_type=$_POST['id_product_type'];
											else
												$id_product_type=$_GET['id_product_type'];
												
										    while($row=mysql_fetch_array($rs)){ 
	  											if($id_product_type==$row['id_product_type']){
	  										?>
	  										<option value="<?php echo $row['id_product_type'];?>" selected><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
	  										<?php 
	  											}else{
	  											?>
	  										<option value="<?php echo $row['id_product_type'];?>"><?php echo  $row['product_type_code']."-".$row['product_type_name'];?></option>
	  										<?php	
	  											}
	  											}?>
	  										
	  									</select>
	  									
	  								</div>
                                      <div class="btn-group pull-right" style="padding-top:1px">
                                      	<a href="#" onclick="javascript: openPopUp('product_in_add.php','Nhập hàng',850,600);"><button class="btn btn-success">Nhập hàng <i class="icon-plus icon-white"></i></button></a>
                                         <button data-toggle="dropdown" class="btn dropdown-toggle">Export <span class="caret"></span></button>
                                         <ul class="dropdown-menu">
                                            <!--<li><a href="#">Print</a></li>
                                            <li><a href="#">Save as PDF</a></li>-->
                                            <li><a href="product_export_excel_xlsx.php">Export to Excel</a></li>
                                         </ul>
                                      </div>
                                 </form>
                            </div>
                            
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
                                        <thead>
                                            <tr>
                                                <th>STT</th>
                                                <th>Mã sản phẩm</th>
                                                <th>Tên sản phẩm</th>
                                                <th>Kích cỡ</th>
                                                <th>Số lượng nhập</th>
                                                <th>Giá nhập</th>
                                                <th>Chú thích</th>                                                
                                                <th>Ngày cập nhật</th>
                                                <th>Thao tác</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php 
                                        if($id_product_type>0)
                                        	$sql="select i.*, p.product_name from product_in i, product p where i.id_product=p.id_product and p.id_product_type=".$id_product_type." order by i.id_product_in desc";
                                        else
                                        	$sql="select i.*, p.product_name from product_in i, product p where i.id_product=p.id_product order by i.id_product_in desc";	
										//echo $sql;
										try{
											$rs=mysql_db_query($db,$sql,$con);					  
															
										}catch (Exception $e){
											//writeLog($e);
										}
										
                                        $i=0;
                                        while($row=mysql_fetch_array($rs)){
                                        	$i++;
                                        	$price_in=number_format($row['price_in']);
                                        	if($i%2){
                                        ?>
                                            <tr class="even gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td><?php echo $row['quantity'];?></td>                                                
                                                <td class="center"><?php echo $price_in;?></td>
                                                <td class="center"><?php echo $row['product_in_note'];?></td>
                                                <td class="center"><?php echo $row['updated_datetime'];?></td>
                                                <td class="center"><a href="#" onclick="javascript: openPopUp('product_in_add.php?id=<?php echo $row["id_product_in"];?>','Sản phẩm',850,600);">Sửa</a> - <a href="product_in_list.php?iddel=<?php echo $row["id_product_in"].'&id_product_type='.$id_product_type;?>" onClick="return del();">Xóa</a></td>
                                            </tr>
                                            <?php }else{ ?>
                                            <tr class="odd gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo $row['product_code'];?></td>
                                                <td><?php echo $row['product_name'];?></td>
                                                <td><?php echo $row['size'];?></td>
                                                <td><?php echo $row['quantity'];?></td>                                                
                                                <td class="center"><?php echo $price_in;?></td>
                                                <td class="center"><?php echo $row['product_in_note'];?></td>
                                                <td class="center"><?php echo $row['updated_datetime'];?></td>
                                                <td class="center"><a href="#" onclick="javascript: openPopUp('product_in_add.php?id=<?php echo $row["id_product_in"];?>','Sản phẩm',850,600);">Sửa</a> - <a href="product_in_list.php?iddel=<?php echo $row["id_product_in"].'&id_product_type='.$id_product_type;?>" onClick="return del();">Xóa</a></td>
                                            </tr>                                           
                                        <?php 
                                            }
                                        }
                                        ?>                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div> 
        <!--/.fluid-container-->
        
        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>