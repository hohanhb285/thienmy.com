<!DOCTYPE html>
<html>
    
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
 <?php 
 if($_GET["id"]){
 	$sql="select * from product_type where id_product_type=".$_GET["id"];
	//echo $sql;
	$rse=mysql_db_query($db,$sql,$con);	
	$rowe=mysql_fetch_array($rse);
 	$product_type_code=$rowe["product_type_code"];
	$product_type_name=$rowe["product_type_name"];
	$product_type_note=$rowe["product_type_note"];
 }
 
 if ($_POST["sm_1"] || $_POST["sm_2"]){ 	
	$product_type_code=strtoupper($_POST["product_type_code"]);
	$product_type_name=$_POST["product_type_name"];
	$product_type_note=$_POST["product_type_note"];
	$created_datetime=date('Y-m-d H:m:s',time());
	$sMesage='';
	 if($_POST["product_type_code"]=='')   
	 	$sMesage="Bạn chưa nhập Mã loại sản phẩm";	
	 elseif(strlen($_POST["product_type_code"])<2 || strlen($_POST["product_type_code"])>3)
	 	$sMesage="Mã loại sản phẩm phải 2 hoặc 3 kí tự.";
	 if($_POST["product_type_name"]=='')   
	 	$sMesage.="<br>Bạn chưa nhập Tên loại sản phẩm";		
	 	
	try{
		if($sMesage==''){
			if($_GET["id"])
				$sql="update product_type set product_type_name='$product_type_name',product_type_note='$product_type_note',updated_datetime='$created_datetime' where id_product_type=".$_GET["id"];
			else{
				$sql="insert into product_type(product_type_code,product_type_name,product_type_note,updated_datetime,created_datetime) values ";
				$sql=$sql."('$product_type_code','$product_type_name','$product_type_note','$created_datetime','$created_datetime')";
			}	
			//echo $sql;
			
			if (mysql_db_query($db,$sql,$con)){
				 $sMesage="Thao tác thành công";
				 if($_POST["sm_1"]){
				 	?>
				 	<script>refresh();</script>
				 	<?php
				 }else{
				 	?>
				 	<script>refreshAndClose();</script>
				 	<?php
				 }	 
			 }else{
				 $sMesage="Thao tác không thành công"; 		 
		     }
		     if (substr(mysql_error(),0,9)=='Duplicate'){
		     	 $sMesage="Mã này đã tồn tại. Vui lòng nhập mã khác.";
		     }
		}
	}catch (Exception $e){
		//writeLog($e);
	}
     
 }
 ?>
    <body>
        <?php //include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php //include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%">
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid" >
                        <!-- block -->
                        <div class="block" >
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Nhập loại sản phẩm</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <form class="form-horizontal" id="frm_1"  method="post">
                                      <fieldset>
                                        <div class="control-group error" style="text-align: center">
                                          <label class="control-label" for="inputError" style="padding-left:22%;width:50%;text-align:left"><?php echo $sMesage; ?></label>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="product_type_code">Mã loại <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="product_type_code" <?php if ($_GET["id"] && $product_type_code) echo "readonly"; ?>  value="<?php echo $product_type_code;?>">                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="product_type_name">Tên loại <span class="required">*</span></label>
                                          <div class="controls">
                                            <input type="text" class="span6" name="product_type_name" value="<?php echo $product_type_name;?>">                                            
                                          </div>
                                        </div>                                        
                                        <div class="control-group">
                                          <label class="control-label" for="product_type_note">Chú thích</label>
                                          <div class="controls">
                                            <textarea name='product_type_note' rows="3" class="input-xlarge textarea" placeholder="Enter text ..." style="width: 90%;"><?php echo $product_type_note;?></textarea>
                                          </div>
                                        </div>                                      
                                       <div class="form-actions">
                                          <button type="submit" name="sm_1" value="1" class="btn btn-primary">Save</button>
                                          <button type="submit" name="sm_2" value="1" class="btn btn-primary">Save and Close</button>
                                          <button type="reset" name="cc_1" value="1" class="btn">Reset</button>
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div>
 
        <!--/.fluid-container-->
        <link href="vendors/datepicker.css" rel="stylesheet" media="screen">
        <link href="vendors/uniform.default.css" rel="stylesheet" media="screen">
        <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">

        <link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/jquery.uniform.min.js"></script>
        <script src="vendors/chosen.jquery.min.js"></script>
        <script src="vendors/bootstrap-datepicker.js"></script>

        <script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
        <script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

        <script src="vendors/wizard/jquery.bootstrap.wizard.min.js"></script>

	<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
	<script src="assets/form-validation.js"></script>
        
	<script src="assets/scripts.js"></script>
        <script>

	jQuery(document).ready(function() {   
	   FormValidation.init();
	});
	

        $(function() {
            $(".datepicker").datepicker();
            $(".uniform_on").uniform();
            $(".chzn-select").chosen();
            $('.textarea').wysihtml5();

            $('#rootwizard').bootstrapWizard({onTabShow: function(tab, navigation, index) {
                var $total = navigation.find('li').length;
                var $current = index+1;
                var $percent = ($current/$total) * 100;
                $('#rootwizard').find('.bar').css({width:$percent+'%'});
                // If it's the last tab then hide the last button and show the finish instead
                if($current >= $total) {
                    $('#rootwizard').find('.pager .next').hide();
                    $('#rootwizard').find('.pager .finish').show();
                    $('#rootwizard').find('.pager .finish').removeClass('disabled');
                } else {
                    $('#rootwizard').find('.pager .next').show();
                    $('#rootwizard').find('.pager .finish').hide();
                }
            }});
            $('#rootwizard .finish').click(function() {
                alert('Finished!, Starting over!');
                $('#rootwizard').find("a[href*='tab1']").trigger('click');
            });
        });
        </script>
    </body>

</html>