 <?php include_once("connect.inc.php");?>   
 <?php 
 $sql="select * from product where product_code is null order by id_product asc limit 0,100";
 //echo $sql;
 $rs=mysql_db_query($db,$sql,$con);	
 while($row=mysql_fetch_array($rs)){ 
 	if($row["id_product_type"]==1)
 		$product_type_code="INO";
 	if($row["id_product_type"]==2)
 		$product_type_code="SU";
 	if($row["id_product_type"]==3)
 		$product_type_code="THA";
 	if($row["id_product_type"]==4)
 		$product_type_code="NOI";	
 				
 	$product_code=$product_type_code."-".substr(rand(1,10000)+microtime(),-4);
 	$sqle="update product set product_code='$product_code' where id_product=".$row["id_product"];
 	echo "<br>".$sqle;
 	mysql_db_query($db,$sqle,$con);	
 	usleep(2);
 }
 echo "Done";
 ?>
 