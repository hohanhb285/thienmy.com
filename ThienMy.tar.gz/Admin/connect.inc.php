<?php 
$db='BackEnd';
$con=mysql_connect('localhost','root','root');

if (!$con)
 die("Could not connect database.".mysql_error()); 
 mysql_query("SET NAMES utf8",$con);
//mysql_query("SET NAMES UTF8",$con);

/*
$mysqli_con = mysqli_connect("localhost", "root", "root", "BackEnd");

if (!$mysqli_con) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}

//mysqli_close($mysqli_con);
 
*/
?>