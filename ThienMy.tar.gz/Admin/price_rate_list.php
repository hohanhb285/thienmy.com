<!DOCTYPE html>
<html>
    
    <head>
        <?php include_once("header.php");?>
        <?php include_once("connect.inc.php");?>
    </head>
    <script src="lib/common.js"></script>
    <?php 
    if($_GET["iddel"]){
    	$sql="delete from price_rate where id_price_rate=".$_GET["iddel"];
    	mysql_db_query($db,$sql,$con);
    }
    
 	$sql="select * from price_rate order by id_price_rate asc";
	//echo $sql;
	try{
		$rs=mysql_db_query($db,$sql,$con);					  
						
	}catch (Exception $e){
		//writeLog($e);
	}
    ?>
    <body>
        <?php include_once("top.php");?>
        <div class="container-fluid">
            <div class="row-fluid">
                <?php include_once("left.php");?>                
                <div class="span9" id="content" style="width:100%" >
                    <!-- morris stacked chart -->                   

                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Danh sách tỉ lệ lợi nhuận</div>
                                      <div class="btn-group pull-right" style="padding-top:1px">
                                      	<a href="#" onclick="javascript: openPopUp('price_rate_add.php','Nhập tỉ lệ lợi nhuận',850,600);"><button class="btn btn-success">Thêm <i class="icon-plus icon-white"></i></button></a>
                                         <button data-toggle="dropdown" class="btn dropdown-toggle">Export <span class="caret"></span></button>
                                         <ul class="dropdown-menu">
                                            <li><a href="#">Print</a></li>
                                            <li><a href="#">Save as PDF</a></li>
                                            <li><a href="#">Export to Excel</a></li>
                                         </ul>
                                      </div>
                                 
                            </div>
                            
                            <div class="block-content collapse in">
                                <div class="span12">
                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example2">
                                        <thead>
                                            <tr>
                                                <th>STT</th>
                                                <th>Giá từ</th>
                                                <th>Giá đến</th>
                                                <th>Phần trăm</th>
                                                <th>Ngày cập nhật</th>
                                                <th>Thao tác</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php 
                                        $i=0;
                                        while($row=mysql_fetch_array($rs)){
                                        	$i++;
                                        	if($i%2){
                                        ?>
                                            <tr class="even gradeA">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo number_format($row['from_value']);?></td>
                                                <td><?php echo number_format($row['to_value']);?></td>
                                                <td class="center"><?php echo $row['percent'];?></td>
                                                <td class="center"><?php echo $row['updated_datetime'];?></td>
                                                <td class="center"><a href="#" onclick="javascript: openPopUp('price_rate_add.php?id=<?php echo $row["id_price_rate"];?>','Tỉ lệ lợi nhuận',850,600);">Sửa</a> - <a href="price_rate_list.php?iddel=<?php echo $row["id_price_rate"];?>" onClick="return del();">Xóa</a></td>
                                            </tr>
                                            <?php }else{ ?>
                                            <tr class="odd gradeC">
                                                <td><?php echo $i;?></td>
                                                <td><?php echo number_format($row['from_value']);?></td>
                                                <td><?php echo number_format($row['to_value']);?></td>
                                                <td class="center"><?php echo $row['percent'];?></td>
                                                <td class="center"><?php echo $row['updated_datetime'];?></td>
                                                <td class="center"><a href="#" onclick="javascript: openPopUp('price_rate_add.php?id=<?php echo $row["id_price_rate"];?>','Tỉ lệ lợi nhuận',850,600);">Sửa</a> - <a href="price_rate_list.php?iddel=<?php echo $row["id_price_rate"];?>" onClick="return del();">Xóa</a></td>
                                            </tr>
                                            
                                        <?php 
                                            }
                                        }
                                        ?>                                        
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                </div>
            </div>
            <hr>
            <footer>
                <?php include_once("footer.php");?>
            </footer>
        </div> 
        <!--/.fluid-container-->
        
        <script src="vendors/jquery-1.9.1.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="vendors/datatables/js/jquery.dataTables.min.js"></script>


        <script src="assets/scripts.js"></script>
        <script src="assets/DT_bootstrap.js"></script>
        <script>
        $(function() {
            
        });
        </script>
    </body>

</html>