<?php
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2014 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2014 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.8.0, 2014-03-02
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
//die(dirname(__FILE__));
include_once("connect2.inc.php");
require_once dirname(__FILE__) . '/lib/export_excel/Classes/PHPExcel.php';



// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("Thien My")
							 ->setLastModifiedBy("Thien My")
							 ->setTitle("Office 2007 XLSX Test Document")
							 ->setSubject("Office 2007 XLSX Test Document")
							 ->setDescription("Document for Office 2007 XLSX, generated using PHP classes.")
							 ->setKeywords("office 2007 openxml php")
							 ->setCategory("Result file");


// Add some data
$sql="select p.*, t.product_type_name from product_type t, product p where p.id_product_type=t.id_product_type";
//echo $sql;
try{
	$rowNumber=1;
	$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$rowNumber, 'STT')
		            ->setCellValue('B'.$rowNumber, 'Mã sản phầm')
		            ->setCellValue('C'.$rowNumber, 'Tên sản phẩm')
		            ->setCellValue('D'.$rowNumber, 'Hình')
		            ->setCellValue('E'.$rowNumber, 'Loại')
		            ->setCellValue('F'.$rowNumber, 'Chú thích')
		            ->setCellValue('G'.$rowNumber, 'Cập nhật');
		            
	$rs=$mysqli_con->query($sql);					  
	$rowNumber=2;
	while($row=$rs->fetch_object()){
		$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A'.$rowNumber, $rowNumber-1)
		            ->setCellValue('B'.$rowNumber, $row->product_code)
		            ->setCellValue('C'.$rowNumber, $row->product_name)
		            ->setCellValue('D'.$rowNumber, $row->image_name)
		            ->setCellValue('E'.$rowNumber, $row->product_type_name)
		            ->setCellValue('F'.$rowNumber, $row->product_note)
		            ->setCellValue('G'.$rowNumber, $row->updated_datetime);
		            
		$objDrawing = new PHPExcel_Worksheet_Drawing();
		$objDrawing->setName('Hinh san pham');
		$objDrawing->setDescription('Hinh san pham');
		$objDrawing->setPath('product_image/'.$row->image_name);
		$objDrawing->setCoordinates('D'.$rowNumber);
		$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
		
		$rowNumber++;                
	}				
}catch (Exception $e){
	//writeLog($e);
}
	
           
// Save the workbook
//$objPHPExcelWriter = PHPExcel_IOFactory::createWriter($objPHPExcel,$fileType);
//$objPHPExcelWriter->save($fileName); 

// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle('Simple');


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);

$file_name='product_'.date('dmY',time()).'.xlsx';

// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename='.$file_name);
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;
