					<div style="text-align:left; float:left; padding-left: 100px">
	                    <br>Ngày ....... Tháng ......Năm.......
	                    <br> 
	                    <br>Giao hàng xác nhận 
	                    <br>
	                    <br>
	                    <br>
	                    <br>
	                    <br> 
	                    <br>
	                    <br> 
	                 </div>
	                 	<div style="text-align:right; padding-right: 100px ">
	                    <br>Ngày ....... Tháng ......Năm.......
	                    <br>
						<br>Khách hàng xác nhận 
	                    <br>
	                    <br> 
	                    <br>
	                    <br>
	                    <br>
	                    <br> 
	                    <br>
	                    <br> 
	                 </div>
